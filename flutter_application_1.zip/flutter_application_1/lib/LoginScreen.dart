import 'package:flutter/material.dart';

void main() {
  runApp(const LoginScreen());
}

class Loginscreen extends StatelessWidget{
  Loginscreen({super.key})

  @override
  Widget build(BuildContext context){
    return MaterialApp(
      title: 'Tela de Login',
      home: Scaffold(
        appBar: AppBar(),
        drawer: Drawer(),
        body: Align(
          alignment: Alignment.center,
          child: Container(
            width: 150,
            child: TextField(decoration: InputDecoration(labelText: 'Email'),
            style: TextStyle(color: Colors.black, fontSize: 16),),
            
          ),
        )
        bottomNavigationBar: BottomNavigationBar(
          items: <BottomNavigationBarItem> [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
            BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Minha Conta')
          ]),
      ),
    );
  }

}