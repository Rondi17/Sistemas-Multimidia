import 'package:flutter/material.dart';
import 'package:flutter_application_1/main.dart';

void main() {
  runApp(const Hello());
}

class Hello extends StatelessWidget {
  const Hello({super.key});

  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Atividade Pratica',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
              seedColor: const Color.fromARGB(255, 58, 183, 93)),
          useMaterial3: true,
        ),
        home: const Scaffold(
          body: const Center(child: Text("Hello World")),
        ));
  }
}
